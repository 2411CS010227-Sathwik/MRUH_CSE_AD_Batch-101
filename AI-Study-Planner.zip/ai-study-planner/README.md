# AI Study Planner

A responsive React application for programming learners. It includes a public landing page, student workspace, course roadmaps, a task-based study planner, calendar, assessment discovery, AI tutor and code reviewer interfaces, coding playground, challenges, revision cards, progress views, profile/settings, and an admin dashboard preview.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
cp .env.example .env
npm run dev
```

Open the Vite URL shown in the terminal (usually http://localhost:5173).

The student sign-in is currently a **local demo mode**: it stores a demo profile and progress in the browser's localStorage. Do not use real passwords or personal data in this mode. It is intended to let you explore the UI and interactions before connecting a real auth provider.

## Optional AI backend

```bash
npm install express cors dotenv helmet express-rate-limit
```

Set `OPENAI_API_KEY` and optionally `OPENAI_MODEL` / `OPENAI_BASE_URL` in `.env`, then run in another terminal:

```bash
npm run server
```

The frontend AI tutor and code reviewer call `/api/ai/*`. In local development, add a Vite proxy in `vite.config.js` or run a reverse proxy so `/api` reaches `http://localhost:4000` (example config below).

Create `vite.config.js`:

```js
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({ plugins:[react()], server:{proxy:{'/api':'http://localhost:4000'}} });
```

## Database and production authentication

1. Create a Supabase project.
2. Run `database/schema.sql` in the Supabase SQL editor.
3. Configure `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
4. Integrate Supabase Auth in the login/register forms and replace the local demo store with authenticated database queries.
5. Keep service-role keys and all provider secrets server-side only.
6. Review and test every RLS policy before production. The SQL intentionally gives ordinary students access only to their own user-owned records. Admin operations must be performed by a trusted server-side role check; never trust a client-side role field.

The starter UI does not yet wire every screen to Supabase. The SQL schema provides the relational foundation for courses, modules, lessons, enrollments, study plans/tasks/sessions, exams/questions/attempts/answers, coding challenges/submissions, revisions, projects, notifications, AI history, and feedback.

## Secure code execution

The playground deliberately does **not** use `eval`, `Function`, or server-side shell execution. Configure a trusted Judge0-compatible isolated runner using `JUDGE0_URL` and `JUDGE0_API_KEY` on the backend. Review provider limits, network restrictions, execution timeouts, memory caps, and API authentication before enabling it.

## Production checklist

- Replace local demo auth with Supabase Auth or a secure server-side auth system.
- Add verified email/password reset, session refresh, logout, and role-based route/API authorization.
- Connect the app to Supabase queries and remove sample analytics from the progress view.
- Store course content, exams, question banks, submissions, and results in the database.
- Generate study recommendations from persisted completion and assessment data; validate AI output before saving.
- Add tests for auth, ownership/RLS, exam evaluation, time limits, and sandbox isolation.
- Configure HTTPS, secure cookies, CORS allowlists, rate limits, logging, backups, and privacy/retention policies.

## Main routes

Public: `/`, `/login`, `/register`, `/forgot-password`.

Student workspace: `/app`, `/app/onboarding`, `/app/courses`, `/app/course/:id`, `/app/planner`, `/app/calendar`, `/app/exams`, `/app/tutor`, `/app/reviewer`, `/app/playground`, `/app/challenges`, `/app/progress`, `/app/weak-areas`, `/app/revision`, `/app/projects`, `/app/profile`, `/app/notifications`, `/app/settings`.

Admin preview: `/app/admin` (requires a real server-verified admin role before production use).
