-- PostgreSQL schema for AI Study Planner. Apply to a fresh Supabase/Postgres project.
create extension if not exists pgcrypto;
create type public.app_role as enum ('student','admin');
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '', email text unique,
  college text, academic_year text, experience text default 'Beginner',
  role public.app_role not null default 'student',
  learning_goal text, daily_study_minutes int default 90,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.courses (
  id uuid primary key default gen_random_uuid(), slug text unique not null,
  name text not null, category text, description text, difficulty text,
  is_published boolean not null default false, created_at timestamptz default now()
);
create table public.modules (
  id uuid primary key default gen_random_uuid(), course_id uuid not null references public.courses(id) on delete cascade,
  title text not null, position int not null default 0
);
create table public.lessons (
  id uuid primary key default gen_random_uuid(), module_id uuid not null references public.modules(id) on delete cascade,
  title text not null, content_md text, code_example text, position int not null default 0
);
create table public.enrollments (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  enrolled_at timestamptz default now(), unique(user_id,course_id)
);
create table public.lesson_progress (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  completed boolean not null default false, completed_at timestamptz, unique(user_id,lesson_id)
);
create table public.study_plans (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null, start_date date not null, end_date date, generated_by text default 'rules',
  preferences jsonb not null default '{}', created_at timestamptz default now()
);
create table public.study_tasks (
  id uuid primary key default gen_random_uuid(), plan_id uuid not null references public.study_plans(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  course_id uuid references public.courses(id) on delete set null,
  title text not null, task_type text, scheduled_for timestamptz, duration_minutes int default 30,
  status text not null default 'pending' check(status in ('pending','completed','skipped')),
  completed_at timestamptz, created_at timestamptz default now()
);
create table public.study_sessions (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  course_id uuid references public.courses(id) on delete set null,
  started_at timestamptz not null, ended_at timestamptz, duration_minutes int, notes text
);
create table public.exams (
  id uuid primary key default gen_random_uuid(), title text not null, course_id uuid references public.courses(id) on delete set null,
  duration_minutes int not null default 30, published boolean not null default false,
  created_by uuid references public.profiles(id), created_at timestamptz default now()
);
create table public.questions (
  id uuid primary key default gen_random_uuid(), exam_id uuid not null references public.exams(id) on delete cascade,
  question_type text not null, prompt text not null, options jsonb, correct_answer jsonb,
  explanation text, topic text, marks numeric default 1, position int default 0
);
create table public.exam_attempts (
  id uuid primary key default gen_random_uuid(), exam_id uuid not null references public.exams(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  started_at timestamptz default now(), submitted_at timestamptz, score numeric, max_score numeric,
  status text default 'in_progress'
);
create table public.student_answers (
  id uuid primary key default gen_random_uuid(), attempt_id uuid not null references public.exam_attempts(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  answer jsonb, is_correct boolean, marks_awarded numeric default 0, unique(attempt_id,question_id)
);
create table public.challenges (
  id uuid primary key default gen_random_uuid(), title text not null, slug text unique,
  difficulty text, language text, prompt_md text, starter_code text, test_cases jsonb,
  solution_explanation text, is_published boolean default false
);
create table public.code_submissions (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  challenge_id uuid references public.challenges(id) on delete set null,
  language text not null, source_code text not null, verdict text, runtime_ms int, memory_kb int,
  submitted_at timestamptz default now()
);
create table public.revision_items (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  lesson_id uuid references public.lessons(id) on delete cascade, due_at timestamptz not null,
  interval_days int default 1, ease_factor numeric default 2.5, repetitions int default 0,
  last_reviewed_at timestamptz
);
create table public.projects (
  id uuid primary key default gen_random_uuid(), title text not null, description text,
  course_id uuid references public.courses(id) on delete set null, difficulty text, is_published boolean default false
);
create table public.project_progress (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  project_id uuid not null references public.projects(id) on delete cascade,
  status text default 'not_started', notes text, updated_at timestamptz default now(), unique(user_id,project_id)
);
create table public.notifications (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null, body text, category text, read_at timestamptz, created_at timestamptz default now()
);
create table public.ai_interactions (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  interaction_type text not null, prompt text not null, response text, metadata jsonb default '{}',
  created_at timestamptz default now()
);
create table public.feedback (
  id uuid primary key default gen_random_uuid(), user_id uuid references public.profiles(id) on delete set null,
  subject text, message text not null, status text default 'open', created_at timestamptz default now()
);
-- Enable RLS on user-owned tables. Admin access should be granted through a trusted server-side role check.
alter table public.profiles enable row level security;
alter table public.enrollments enable row level security;
alter table public.lesson_progress enable row level security;
alter table public.study_plans enable row level security;
alter table public.study_tasks enable row level security;
alter table public.study_sessions enable row level security;
alter table public.exam_attempts enable row level security;
alter table public.student_answers enable row level security;
alter table public.code_submissions enable row level security;
alter table public.revision_items enable row level security;
alter table public.project_progress enable row level security;
alter table public.notifications enable row level security;
alter table public.ai_interactions enable row level security;
alter table public.feedback enable row level security;
create policy "profile owner can read and update" on public.profiles for select using (auth.uid()=id);
create policy "profile owner can update" on public.profiles for update using (auth.uid()=id) with check (auth.uid()=id);
create policy "owner manages enrollments" on public.enrollments for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "owner manages lesson progress" on public.lesson_progress for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "owner manages study plans" on public.study_plans for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "owner manages study tasks" on public.study_tasks for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "owner manages sessions" on public.study_sessions for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "owner manages attempts" on public.exam_attempts for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "owner manages answers" on public.student_answers for all using (exists(select 1 from public.exam_attempts a where a.id=attempt_id and a.user_id=auth.uid())) with check (exists(select 1 from public.exam_attempts a where a.id=attempt_id and a.user_id=auth.uid()));
create policy "owner manages code submissions" on public.code_submissions for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "owner manages revisions" on public.revision_items for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "owner manages project progress" on public.project_progress for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "owner manages notifications" on public.notifications for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "owner manages AI interactions" on public.ai_interactions for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "owner creates feedback" on public.feedback for insert with check (user_id is null or auth.uid()=user_id);
-- Public catalog read policies
alter table public.courses enable row level security;
alter table public.modules enable row level security;
alter table public.lessons enable row level security;
alter table public.exams enable row level security;
alter table public.questions enable row level security;
alter table public.challenges enable row level security;
alter table public.projects enable row level security;
create policy "published courses readable" on public.courses for select using (is_published=true);
create policy "published modules readable" on public.modules for select using (exists(select 1 from public.courses c where c.id=course_id and c.is_published=true));
create policy "published lessons readable" on public.lessons for select using (exists(select 1 from public.modules m join public.courses c on c.id=m.course_id where m.id=module_id and c.is_published=true));
create policy "published exams readable" on public.exams for select using (published=true);
-- Do not grant direct student SELECT on questions: correct_answer is stored on this table.
-- Serve question prompts/options through a trusted API that strips answer keys; grade submissions server-side.
create policy "published challenges readable" on public.challenges for select using (is_published=true);
create policy "published projects readable" on public.projects for select using (is_published=true);
