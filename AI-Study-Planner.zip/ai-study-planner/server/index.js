import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

dotenv.config();
const app = express();
app.use(helmet({contentSecurityPolicy:false}));
app.use(cors({origin:process.env.APP_ORIGIN||'http://localhost:5173'}));
app.use(express.json({limit:'200kb'}));
app.use('/api/',rateLimit({windowMs:60_000,limit:45,standardHeaders:true,legacyHeaders:false}));

app.get('/api/health',(_req,res)=>res.json({ok:true,service:'AI Study Planner API'}));
async function askAI(system,prompt){
  if(!process.env.OPENAI_API_KEY) throw new Error('AI_NOT_CONFIGURED');
  const base=(process.env.OPENAI_BASE_URL||'https://api.openai.com/v1').replace(/\/$/,'');
  const response=await fetch(`${base}/chat/completions`,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${process.env.OPENAI_API_KEY}`},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4o-mini',messages:[{role:'system',content:system},{role:'user',content:prompt}],temperature:.4})});
  if(!response.ok) throw new Error(`AI provider returned ${response.status}`);
  const data=await response.json();return data.choices?.[0]?.message?.content||'No response was returned.';
}
app.post('/api/ai/chat',async(req,res)=>{try{const {message,level='Beginner'}=req.body||{};if(typeof message!=='string'||!message.trim()||message.length>12000)return res.status(400).json({error:'A valid message is required.'});const reply=await askAI(`You are a patient programming tutor. Explain concepts at a ${level} level. Use concise step-by-step explanations and safe code examples. Ask a clarifying question when needed.`,message);res.json({reply});}catch(e){res.status(e.message==='AI_NOT_CONFIGURED'?503:502).json({error:e.message==='AI_NOT_CONFIGURED'?'AI service is not configured. Add OPENAI_API_KEY to the server environment.':'The AI service could not complete this request.'});}});
app.post('/api/ai/review',async(req,res)=>{try{const {code,language='text'}=req.body||{};if(typeof code!=='string'||!code.trim()||code.length>30000)return res.status(400).json({error:'Valid code is required.'});const review=await askAI('You are a careful senior software engineer. Review the supplied code for correctness, edge cases, readability, security, and performance. Give prioritized findings with actionable fixes. Do not claim to have executed the code.',`Language: ${language}\n\nCode:\n${code}`);res.json({review});}catch(e){res.status(e.message==='AI_NOT_CONFIGURED'?503:502).json({error:e.message==='AI_NOT_CONFIGURED'?'AI service is not configured.':'The AI review service is unavailable.'});}});
app.post('/api/code/run',async(req,res)=>{const {language,code}=req.body||{};if(typeof code!=='string'||code.length>20000)return res.status(400).json({error:'Valid code is required.'});if(!process.env.JUDGE0_URL)return res.status(503).json({error:'Secure code execution is not configured. Set JUDGE0_URL and JUDGE0_API_KEY.'});try{const response=await fetch(`${process.env.JUDGE0_URL.replace(/\/$/,'')}/submissions?base64_encoded=false&wait=true`,{method:'POST',headers:{'Content-Type':'application/json',...(process.env.JUDGE0_API_KEY?{'X-RapidAPI-Key':process.env.JUDGE0_API_KEY}:{})},body:JSON.stringify({language_id:({javascript:63,python:71,java:62,cpp:54})[language]||63,source_code:code,stdin:''})});const data=await response.json();res.json({output:[data.stdout,data.stderr,data.compile_output,data.message].filter(Boolean).join('\n')||data.status?.description||'No output.'});}catch{res.status(502).json({error:'The code execution provider is unavailable.'});}});
const port=process.env.PORT||4000;app.listen(port,()=>console.log(`AI Study Planner API listening on http://localhost:${port}`));
